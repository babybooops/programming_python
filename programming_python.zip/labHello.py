
print('Hello' * 5)

name = "Миша"
print("Привет, " + name + "!")
print(f"Привет, {name} !")
print("Привет, " , name , "!")

print(1,2,3,4)
print(1,2,3,4, sep=',')
print(1,2,3,4, sep='\n')

def AAA():
    a = 1
    b = 2
    print(a + b)

AAA()